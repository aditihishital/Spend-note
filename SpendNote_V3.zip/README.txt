SpendNote V3
============

IMPORTANT:
- V3 OCR uses Tesseract.js from a CDN.
- For reliable OCR and Android PWA Share Target, serve this folder over HTTPS.
- Opening index.html directly from the Files app (file://) can make OCR/CDN loading fail.
- After hosting over HTTPS, open the site in Chrome Android and use "Add to Home screen"/"Install app".

Main flow:
1. Open SpendNote.
2. Tap Scan.
3. Select a GPay/PhonePe/CRED payment screenshot.
4. Tap Scan screenshot.
5. Check detected amount/merchant/date/time.
6. Tap Confirm & Save Expense.

The included service worker also defines a POST share target at /share for installed PWAs.
